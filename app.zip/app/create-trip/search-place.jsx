import { useNavigation } from 'expo-router';
import { useEffect } from 'react';
import { View } from 'react-native';

export default function SearchPlace() {
    const navigate = useNavigation()

    useEffect(() => {
        navigate.setOptions({

            headerShown: true,
            headerTransparent: true,
            headerTitle: 'Search Place',

        })
    }, [])

  return (
    <View style={{padding:25,paddingTop:75,backgroundColor:'#fff',height:'100%'}}>
      {/* <GooglePlacesAutocomplete
      placeholder='Search'
      onPress={(data, details = null) => {
        // 'details' is provided when fetchDetails = true
        console.log(data, details);
      }}
      query={{
        key: 'YOUR API KEY',
        language: 'en',
      }}
    /> */}
    </View>
  )
}