import { auth } from '@/firebaseConfig';
import { useRouter } from 'expo-router';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { useState } from 'react';
import {
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();
  

  const handleLogin = async () => {
      if (!email || !password) {
        Alert.alert('Error', 'Please fill in both fields.');
        return;
      }
  
      try {
        await signInWithEmailAndPassword(auth, email, password);
        Alert.alert('Success', 'User logged in successfully!');
        setEmail('');
        setPassword('');
        router.push('/(tabs)'); // Navigate to the main app screen after login
      } catch (error: any) {
        Alert.alert('Login Error', error.message);
      }
    };

  return (
    <View>
      <Image
        source={require('./../../assets/images/login.jpeg')}
        style={{ width: '100%', height: 200 }}/>
    <View style={styles.container}>
        <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : undefined}
                style={styles.inner}
              >
          <Text style={styles.heading}>Login Here</Text>

          <TextInput
            placeholder="Email"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            style={styles.input}
            placeholderTextColor="#aaa"
          />
  
          <TextInput
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            style={styles.input}
            placeholderTextColor="#aaa"
          />
  
          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.buttonText}>Login</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => router.push('/register')}>
            <Text style={{ color: '#2563EB', textAlign: 'center', marginTop: 20 }}>
              Don't have an account? Register
            </Text>
          </TouchableOpacity>
          </KeyboardAvoidingView>
      </View>

      </View>
    );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#F9FAFB',
    marginTop: -20,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    height: '100%',
    paddingTop: 20,
  },
  inner: {
    paddingHorizontal: 24,
    justifyContent: 'center',
  },
  heading: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 32,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  button: {
    backgroundColor: '#2563EB',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
    elevation: 2,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});
