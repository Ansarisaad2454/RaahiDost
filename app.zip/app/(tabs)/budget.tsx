// app/(tabs)/index.tsx

import BudgetSuggestions from "@/BudgetSuggestions";

export default function SuggestionsScreen() {
  return <BudgetSuggestions />;
}
