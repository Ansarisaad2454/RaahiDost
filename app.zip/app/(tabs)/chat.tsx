import ChatScreen from '../../ChatScreen';

export default function Chat() {
  return <ChatScreen />;
}
